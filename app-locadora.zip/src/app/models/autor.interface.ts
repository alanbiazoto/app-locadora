export interface Autor {
    id?: number;
    nome: string;
    dtnasc: Date;
    nacionalidade: string;
    img: string;
    obs: Text;
}
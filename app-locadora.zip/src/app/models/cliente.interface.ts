export interface Cliente {
    id?: number;
    cpf: string;
    nome: string;
    idade: number;
}